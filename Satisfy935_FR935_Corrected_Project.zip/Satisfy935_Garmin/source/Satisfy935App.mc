using Toybox.Application;
using Toybox.Graphics;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.WatchUi;
using Toybox.ActivityMonitor;
using Toybox.SensorHistory;

class Satisfy935View extends WatchUi.WatchFace {

    function initialize() {
        WatchFace.initialize();
    }

    function onUpdate(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();

        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();

        var white = Graphics.COLOR_WHITE;
        var light = Graphics.COLOR_LT_GRAY;
        var dark = Graphics.COLOR_DK_GRAY;

        // Segmented top arc — intentionally pixel/simple for the FR935's
        // 240x240, 64-colour MIP display.
        dc.setColor(light, Graphics.COLOR_BLACK);
        for (var i = 0; i < 12; i++) {
            var a0 = 205 + i * 6;
            var a1 = a0 + 3;
            drawArcSegment(dc, w / 2, h / 2, 94, a0, a1);
        }

        var info = Gregorian.info(Time.now(), Gregorian.FORMAT_SHORT);
        var hour = info.hour;
        var minute = info.min;

        var hh = hour.format("%02d");
        var mm = minute.format("%02d");

        var dayNames = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
        var dayIndex = info.weekday - 1;
        if (dayIndex < 0 || dayIndex > 6) {
            dayIndex = 0;
        }

        var dateText = dayNames[dayIndex] + ". " +
                       info.day.format("%02d") + "." +
                       info.month.format("%02d");

        // Top micro data
        dc.setColor(light, Graphics.COLOR_BLACK);
        dc.drawText(95, 31, Graphics.FONT_XTINY, "21", Graphics.TEXT_JUSTIFY_LEFT);

        // Date + big time
        dc.setColor(white, Graphics.COLOR_BLACK);
        dc.drawText(43, 61, Graphics.FONT_SMALL, dateText, Graphics.TEXT_JUSTIFY_LEFT);

        dc.setColor(light, Graphics.COLOR_BLACK);
        dc.drawText(43, 76, Graphics.FONT_LARGE, hh + ":" + mm, Graphics.TEXT_JUSTIFY_LEFT);

        // Right column
        dc.setColor(white, Graphics.COLOR_BLACK);
        dc.drawText(165, 70, Graphics.FONT_SMALL, "SATISFY", Graphics.TEXT_JUSTIFY_LEFT);

        var am = ActivityMonitor.getInfo();
        var steps = 0;
        var kcal = 0;
        var distanceKm = 0.0;

        if (am != null) {
            if (am.steps != null) {
                steps = am.steps;
            }
            if (am.calories != null) {
                kcal = am.calories;
            }
            if (am.distance != null) {
                // ActivityMonitor distance is centimetres on supported devices.
                distanceKm = am.distance / 100000.0;
            }
        }

        var hrText = "--";
        if ((Toybox has :SensorHistory) &&
            (Toybox.SensorHistory has :getHeartRateHistory)) {

            var hrIter = SensorHistory.getHeartRateHistory(
                {:period => 1, :order => SensorHistory.ORDER_NEWEST_FIRST}
            );

            if (hrIter != null) {
                var sample = hrIter.next();
                if (sample != null && sample.data != null) {
                    hrText = sample.data.toString();
                }
            }
        }

        dc.drawText(166, 85, Graphics.FONT_SMALL,
                    distanceKm.format("%.1f") + " KM", Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(166, 98, Graphics.FONT_SMALL,
                    hrText + " BPM", Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(166, 111, Graphics.FONT_SMALL,
                    steps.toString(), Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(166, 124, Graphics.FONT_SMALL,
                    kcal.toString(), Graphics.TEXT_JUSTIFY_LEFT);

        // Left labels
        dc.setColor(white, Graphics.COLOR_BLACK);
        dc.drawText(42, 111, Graphics.FONT_SMALL, "RUN", Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(42, 126, Graphics.FONT_SMALL, "HEART RATE", Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(42, 141, Graphics.FONT_SMALL, "RECOVERY", Graphics.TEXT_JUSTIFY_LEFT);
        dc.drawText(42, 156, Graphics.FONT_SMALL, "KCAL", Graphics.TEXT_JUSTIFY_LEFT);

        // Garmin FR935 does not expose COROS's exact recovery field through
        // the same API. Keep the visual field but use a neutral placeholder.
        dc.setColor(light, Graphics.COLOR_BLACK);
        dc.drawText(166, 141, Graphics.FONT_SMALL, "--", Graphics.TEXT_JUSTIFY_LEFT);

        // Halftone panel
        dc.setColor(dark, Graphics.COLOR_BLACK);
        for (var y = 165; y < 210; y += 3) {
            for (var x = 39; x < 203; x += 3) {
                if (((x / 3) + (y / 3)) % 2 == 0) {
                    dc.drawPoint(x, y);
                }
            }
        }

        // Minimal waveform / recovery-style graph
        dc.setColor(light, Graphics.COLOR_BLACK);
        var pts = [
            [43,204], [54,201], [65,196], [77,188], [89,183],
            [101,184], [113,179], [125,184], [137,190],
            [149,186], [161,177], [173,181], [185,176], [198,170]
        ];

        for (var p = 0; p < pts.size() - 1; p++) {
            dc.drawLine(
                pts[p][0], pts[p][1],
                pts[p + 1][0], pts[p + 1][1]
            );
        }

        // Sunrise-style marker — fixed visual placeholder to preserve the
        // reference composition; can be replaced with Garmin sun event data.
        dc.drawText(121, 168, Graphics.FONT_XTINY, "17:47",
                    Graphics.TEXT_JUSTIFY_LEFT);
    }

    function drawArcSegment(dc, cx, cy, radius, startDeg, endDeg) {
        var steps = 3;
        var prevX = cx + Math.cos(startDeg * Math.PI / 180.0) * radius;
        var prevY = cy + Math.sin(startDeg * Math.PI / 180.0) * radius;

        for (var i = 1; i <= steps; i++) {
            var deg = startDeg + ((endDeg - startDeg) * i / steps);
            var x = cx + Math.cos(deg * Math.PI / 180.0) * radius;
            var y = cy + Math.sin(deg * Math.PI / 180.0) * radius;
            dc.drawLine(prevX, prevY, x, y);
            prevX = x;
            prevY = y;
        }
    }
}

class Satisfy935App extends Application.AppBase {
    function getInitialView() {
        return [ new Satisfy935View() ];
    }
}
